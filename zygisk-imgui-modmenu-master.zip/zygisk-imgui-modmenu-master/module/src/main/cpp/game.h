#ifndef ZYGISK_IMGUI_MODMENU_GAME_H
#define ZYGISK_IMGUI_MODMENU_GAME_H

// TODO: change this
#define TargetLibName "libil2cpp.so"
#define GamePackageName "com.game.packagename"

#endif //ZYGISK_IMGUI_MODMENU_GAME_H
