#pragma once

#include "MemoryAllocator/AssemblyCodeBuilder.h"

CodeBufferBase *GenerateNormalTrampolineBuffer(addr_t from, addr_t to);