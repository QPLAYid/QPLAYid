#ifndef ASYNC_LOGGER_H
#define ASYNC_LOGGER_H

void async_logger_print(char *str);

void async_logger_init(char *logger_path);

#endif